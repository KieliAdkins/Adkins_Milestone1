﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShipMovement : MonoBehaviour {
    // Declare our variables
    private SpriteRenderer theRenderer;
  
    // Use this for initialization
    void Start () {
        // Load the SpriteRenderer component
        theRenderer = gameObject.GetComponent<SpriteRenderer>();

        // Checking for null error
        if (theRenderer != null)
        {
        }
    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
